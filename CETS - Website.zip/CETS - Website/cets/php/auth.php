<?php
// php/auth.php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/db.php';

/**
 * Keep session user fields (username, role) in sync with DB.
 */
function auth_refresh(): void {
    if (!isset($_SESSION['user_id'])) return;

    global $conn;
    $stmt = $conn->prepare("SELECT username, role FROM users WHERE id=? LIMIT 1");
    $stmt->bind_param("i", $_SESSION['user_id']);
    if ($stmt->execute()) {
        $stmt->bind_result($username, $role);
        if ($stmt->fetch()) {
            $_SESSION['username'] = $username;
            $_SESSION['role']     = $role;
        }
    }
    $stmt->close();
}

auth_refresh();  // run automatically when included
