<?php
$host = "localhost";
$user = "root";   // default in XAMPP
$pass = "root123";
$dbname = "cets_db";  // must match exactly

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
