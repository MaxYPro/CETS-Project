<?php
session_start();
include 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_id = intval($_POST['booking_id']);
    $type = $_POST['type'];

    if ($type === 'movie') {
        $stmt = $conn->prepare("DELETE FROM bookings WHERE id = ?");
    } else {
        $stmt = $conn->prepare("DELETE FROM event_bookings WHERE id = ?");
    }
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();

    if ($_SESSION['role'] === 'admin') {
        header("Location: ../admin.php");
    } else {
        header("Location: ../profile.php");
    }
    exit();
}
?>
