<?php
session_start();
include 'php/db.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$user = $_SESSION['username'];

// Get user ID
$u = $conn->prepare("SELECT id FROM users WHERE username=?");
$u->bind_param("s", $user);
$u->execute();
$userData = $u->get_result()->fetch_assoc();
$user_id = $userData['id'];

// Fetch movie bookings
$m = $conn->prepare("
    SELECT b.id, m.title, b.cinema, b.date, b.time, b.tickets, b.booking_date
    FROM bookings b
    JOIN movies m ON b.movie_id = m.id
    WHERE b.user_id = ?
    ORDER BY b.booking_date DESC
");
$m->bind_param("i", $user_id);
$m->execute();
$movieBookings = $m->get_result();

// Fetch event bookings
$e = $conn->prepare("
    SELECT eb.id, ev.title, ev.location, ev.date, ev.time, eb.tickets, eb.booked_at
    FROM event_bookings eb
    JOIN events ev ON eb.event_id = ev.id
    WHERE eb.user_id = ?
    ORDER BY eb.booked_at DESC
");
$e->bind_param("i", $user_id);
$e->execute();
$eventBookings = $e->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CETS - Profile</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/account.css">
  <link rel="stylesheet" href="css/profile.css">
  <link rel="shortcut icon" href="img/logoc.png" />
  <script src="https://kit.fontawesome.com/e37f0e4748.js" crossorigin="anonymous"></script>
</head>
<body>
    <?php include 'nav.php'; ?>
  <div class="profile-container">
    <h2><?php echo htmlspecialchars($user); ?>'s Profile</h2>

<h3>🎬 Movie Bookings</h3>
<?php if ($movieBookings->num_rows > 0) { ?>
  <table>
<tr>
  <th>Movie</th>
  <th>Cinema</th>
  <th>Date</th>
  <th>Time</th>
  <th>Tickets</th>
  <th>Booked At</th>
  <th>Action</th>
</tr>

    <?php while ($row = $movieBookings->fetch_assoc()) { ?>
      <tr>
        <td><?php echo htmlspecialchars($row['title']); ?></td>
        <td><?php echo htmlspecialchars($row['cinema']); ?></td>
        <td><?php echo date("d M Y", strtotime($row['date'])); ?></td>
        <td><?php echo date("H:i", strtotime($row['time'])); ?></td>
        <td><?php echo $row['tickets']; ?></td>
        <td><?php echo date("d M Y H:i", strtotime($row['booking_date'])); ?></td>
        <td>
<form class="cancel-form" method="POST" action="php/cancel_booking.php">
    <input type="hidden" name="booking_id" value="<?php echo $row['id']; ?>">
    <input type="hidden" name="type" value="movie">
    <button type="submit" class="cancel-btn">Cancel</button>
</form>


        </td>
      </tr>
    <?php } ?>
  </table>
<?php } else { ?>
  <div class="empty-state">
    <i class="fa-solid fa-film"></i> No movie bookings yet.
  </div>
<?php } ?>


<h3>🎤 Event Bookings</h3>
<?php if ($eventBookings->num_rows > 0) { ?>
  <table>
<tr>
  <th>Event</th>
  <th>Location</th>
  <th>Date</th>
  <th>Time</th>
  <th>Tickets</th>
  <th>Booked At</th>
  <th>Action</th>
</tr>

    <?php while ($row = $eventBookings->fetch_assoc()) { ?>
      <tr>
        <td><?php echo htmlspecialchars($row['title']); ?></td>
        <td><?php echo htmlspecialchars($row['location']); ?></td>
        <td><?php echo date("d M Y", strtotime($row['date'])); ?></td>
        <td><?php echo date("H:i", strtotime($row['time'])); ?></td>
        <td><?php echo $row['tickets']; ?></td>
        <td><?php echo date("d M Y H:i", strtotime($row['booked_at'])); ?></td>
        <td>
<form class="cancel-form" method="POST" action="php/cancel_booking.php">
    <input type="hidden" name="booking_id" value="<?php echo $row['id']; ?>">
    <input type="hidden" name="type" value="event">
    <button type="submit" class="cancel-btn">Cancel</button>
</form>

        </td>
      </tr>
    <?php } ?>
  </table>
<?php } else { ?>
  <div class="empty-state">
    <i class="fa-solid fa-microphone"></i> No event bookings yet.
  </div>
<?php } ?>


  </div>
</body>
</html>
