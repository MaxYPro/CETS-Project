<?php
session_start();
include 'php/db.php';

$result = $conn->query("SELECT * FROM events ORDER BY date ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/logoc.png">
    <title>CETS - Events</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/e37f0e4748.js" crossorigin="anonymous"></script>
</head>
<body>
<?php include("nav.php"); ?>


<section class="slideshow movies-page events-page">
  <h2>🎟️ All Events</h2>
  <div class="now-showing-container movies-grid">
    <?php while($row = $result->fetch_assoc()): ?>
      <div class="movie-card events">
        <img src="img/events/<?php echo $row['poster']; ?>" alt="<?php echo $row['title']; ?>">
        <h3><?php echo $row['title']; ?></h3>
        <p><?php echo date("jS M Y", strtotime($row['date'])); ?></p>
        <p><?php echo date("g:i A", strtotime($row['time'])); ?></p>
<a href="book.php?id=<?php echo $row['id']; ?>&type=event" class="btn small">Book Now</a>
      </div>
    <?php endwhile; ?>
  </div>
</section>

</body>
</html>
