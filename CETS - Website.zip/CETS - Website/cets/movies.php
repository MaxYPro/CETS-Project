<?php
session_start();
include 'php/db.php';

// Fetch all movies
$result = $conn->query("SELECT * FROM movies ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/logoc.png">
    <title>CETS - Movies</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/e37f0e4748.js" crossorigin="anonymous"></script>
</head>
<body>
<?php include("nav.php"); ?>

<section class="slideshow movies-page">
  <h2>🎬 All Movies</h2>
  <div class="now-showing-container movies-grid">
    <?php while($row = $result->fetch_assoc()): ?>
      <div class="movie-card movies">
        <img src="img/movies/<?php echo $row['poster']; ?>" alt="<?php echo $row['title']; ?>">
        <h3><?php echo $row['title']; ?></h3>
<a href="book.php?id=<?php echo $row['id']; ?>" class="btn small">Book Now</a>

      </div>
    <?php endwhile; ?>
  </div>
</section>

</body>
</html>
