<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$current_page = basename($_SERVER['PHP_SELF']);
?>

<nav>
  <a href="index.php">
    <img class="logonav" src="img/logo.png" alt="CETS Logo">
  </a>

  <div class="navbtns" id="navOverlay">
    <li><a href="index.php" class="dashnav <?php if($current_page=='index.php') echo 'active'; ?>">Home</a></li>
    <li><a href="movies.php" class="dashnav <?php if($current_page=='movies.php') echo 'active'; ?>">Movies</a></li>
    <li><a href="events.php" class="dashnav <?php if($current_page=='events.php') echo 'active'; ?>">Events</a></li>
    <li><a href="about.php" class="dashnav <?php if($current_page=='about.php') echo 'active'; ?>">About Us</a></li>
    <li><a href="contact.php" class="dashnav <?php if($current_page=='contact.php') echo 'active'; ?>">Contact</a></li>

    <?php if (isset($_SESSION['username'])): ?>
      <li>
        <a href="profile.php" class="dashnav <?php if($current_page=='profile.php') echo 'active'; ?>">
          <i class="fa-solid fa-user"></i> Profile
        </a>
      </li>

      <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <li>
          <a href="admin.php" class="dashnav <?php if($current_page=='admin.php') echo 'active'; ?>">
            <i class="fa-solid fa-lock"></i>
          </a>
        </li>
      <?php endif; ?>

      <li>
        <a href="#" class="dashnav logoutbtn" onclick="document.getElementById('logoutForm').submit();">
          <i class="fa-solid fa-right-from-bracket"></i>
        </a>
        <form id="logoutForm" action="php/logout.php" method="post" style="display:none;"></form>
      </li>
    <?php else: ?>
      <li>
        <a href="login.php" class="dashnav login <?php if($current_page=='login.php') echo 'active'; ?>">
          <i class="fa-solid fa-right-to-bracket"></i>
        </a>
      </li>
    <?php endif; ?>
  </div>

  <!-- Mobile toggle -->
  <button class="menu-toggle" id="menuToggle" aria-label="Toggle menu">
    <i class="fa-solid fa-bars"></i>
    <i class="fa-solid fa-xmark"></i>
  </button>
</nav>


<script>
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('menuToggle');
  const overlay = document.getElementById('navOverlay');

  function closeMenu() {
    overlay.classList.remove('active');
    toggle.classList.remove('active');
    document.body.classList.remove('menu-open');
  }

  function openMenu() {
    overlay.classList.add('active');
    toggle.classList.add('active');
    document.body.classList.add('menu-open');
  }

  toggle.addEventListener('click', () => {
    if (overlay.classList.contains('active')) {
      closeMenu();
    } else {
      openMenu();
    }
  });

  // close after clicking a link
  overlay.querySelectorAll('a').forEach(a =>
    a.addEventListener('click', closeMenu)
  );

  // reset on desktop resize
  window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
      closeMenu();
    }
  });
});
</script>
