<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="shortcut icon" href="img/logoc.png" />
  <title>CETS - Contact</title>

  <link rel="stylesheet" href="css/style.css" />

  <script src="https://kit.fontawesome.com/e37f0e4748.js" crossorigin="anonymous"></script>
</head>
<body>

<?php include 'nav.php'; ?>

<section class="contact">
  <h1>Contact Us</h1>
  <p class="lead">Got a question, suggestion, or feedback? We’d love to hear from you!</p>

  <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
    <div class="contact-alert success" role="status">
      <i class="fa-solid fa-check-circle"></i>
      Thanks! Your message has been sent.
    </div>
  <?php endif; ?>

  <div class="contact-grid">
    <div class="contact-info">
      <div class="info-card glass">
        <i class="fa-solid fa-envelope"></i>
        <h3>Email</h3>
        <p><a href="mailto:support@cets.com">support@cets.com</a></p>
      </div>

      <div class="info-card glass">
        <i class="fa-solid fa-phone"></i>
        <h3>Phone</h3>
        <p>+44 1234 567890</p>
      </div>

      <div class="info-card glass">
        <i class="fa-solid fa-location-dot"></i>
        <h3>Office</h3>
        <p>Northampton, United Kingdom</p>
      </div>
    </div>

    <form class="contact-form glass" method="post" action="">
      <label class="sr-only" for="name">Your Name</label>
      <input id="name" name="name" type="text" placeholder="Your Name" required />

      <label class="sr-only" for="email">Your Email</label>
      <input id="email" name="email" type="email" placeholder="Your Email" required />

      <label class="sr-only" for="message">Your Message</label>
      <textarea id="message" name="message" placeholder="Your Message" required></textarea>

      <button type="submit" class="btn big">Send Message</button>
    </form>
  </div>
</section>

<footer>
  <p>&copy; 2025 CETS. All rights reserved.</p>
</footer>

</body>
</html>
