<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/logoc.png">
    <title>CETS - Home</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/e37f0e4748.js" crossorigin="anonymous"></script>
</head>

<body>
<?php include 'nav.php'; ?>

<?php

$current_page = basename($_SERVER['PHP_SELF']);
?>


<section class="hero">


  <div class="hero-content">
    <img src="img/logo.png" alt="CETS Logo" class="hero-logo">
    <h1>Book Your Tickets Instantly with <span class="highlight">CETS</span></h1>
    <p>Cinema, Concerts & Live Events — All in one place</p>
    <div class="hero-buttons">
      <a href="events.php" class="btn big">Browse Events</a>
      <a href="register.php" class="btn big">Join Now</a>
    </div>
  </div>
</section>

<section class="slideshow">
  <h2>🎬 Now Showing</h2>
  <div class="now-showing-container">
    <div class="movie-card">
      <img src="img/movies/movie1.jpg" alt="The Batman">
      <h3>The Batman</h3>
    </div>
    <div class="movie-card">
      <img src="img/movies/movie2.jpg" alt="Superman">
      <h3>Superman</h3>
    </div>
    <div class="movie-card highlight">
      <img src="img/movies/movie3.jpg" alt="F1 The Movie">
      <h3>F1 The Movie</h3>
    </div>
    <div class="movie-card">
      <img src="img/movies/movie4.jpg" alt="The Long Walk">
      <h3>The Long Walk</h3>
    </div>
    <div class="movie-card">
      <img src="img/movies/movie5.jpg" alt="Tron: Ares">
      <h3>Tron: Ares</h3>
    </div>
  </div>
  <div style="text-align:center; margin-top:20px;">
    <a href="movies.php" class="btn big">View All</a>
  </div>
</section>




<section class="featured">
  <h2 class="section-title">🎟️ Featured Events</h2>
  <div class="card-container">
    <div class="event-card glass">
      <img src="img/events/event1.jpg" alt="Event 1">
      <h3>Christmas Event: 2025</h3>
      <p>25th Sept 2025</p>
      <a href="events.php" class="btn small">Book Now</a>
    </div>
    <div class="event-card glass">
      <img src="img/events/event2.jpg" alt="Event 2">
      <h3>Hamilton Event</h3>
      <p>1st Oct 2025</p>
      <a href="events.php" class="btn small">Book Now</a>
    </div>
    <div class="event-card glass">
      <img src="img/events/event3.jpg" alt="Event 3">
      <h3>National Theatre Live</h3>
      <p>5th Oct 2025</p>
      <a href="events.php" class="btn small">Book Now</a>
    </div>
  </div>
</section>

<section class="why">
  <h2 class="section-title">✨ Why Choose CETS?</h2>
  <div class="info-cards">
    <div class="info-card glass">
      <i class="fa-solid fa-ticket"></i>
      <h3>Easy Booking</h3>
      <p>Quick and simple ticket purchase process.</p>
    </div>
    <div class="info-card glass">
      <i class="fa-solid fa-lock"></i>
      <h3>Secure Payments</h3>
      <p>Encrypted and safe transactions every time.</p>
    </div>
    <div class="info-card glass">
      <i class="fa-solid fa-bolt"></i>
      <h3>Instant Access</h3>
      <p>Tickets delivered instantly to your profile.</p>
    </div>
  </div>
</section>

<section class="cta glass">
  <h2>Join thousands of people booking with <span class="highlight">CETS</span></h2>
  <a href="register.php" class="btn big">Get Started</a>
</section>


    <footer>
        <p>&copy; 2025 CETS. All rights reserved.</p>
    </footer>

</body>
</html>






<script>
    $(document).ready(function(){
  $(".slider").owlCarousel({
    items: 3,
    margin: 20,
    loop: true,
    autoplay: true,
    autoplayTimeout: 3000,
    autoplayHoverPause: true,
    responsive: {
      0: { items: 1 },
      600: { items: 2 },
      1000: { items: 3 }
    }
  });
});

</script>