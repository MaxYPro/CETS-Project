<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CETS - About Us</title>
  <link rel="shortcut icon" href="img/logoc.png">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://kit.fontawesome.com/e37f0e4748.js" crossorigin="anonymous"></script>
</head>
<body>

<?php include("nav.php"); ?>

<section class="about">
  <div class="about-container glass">
    <h1>About <span class="highlight">CETS</span></h1>
    <p class="intro">
      CETS (Cinema, Events & Ticketing System) is your all-in-one platform to book tickets for 
      <strong>cinemas, concerts, theatre shows, and live events</strong>.  
      Our mission is to make ticket booking simple, secure, and exciting.
    </p>

    <div class="about-cards">
      <div class="about-card glass">
        <i class="fa-solid fa-bullseye"></i>
        <h3>Our Mission</h3>
        <p>To connect people with unforgettable experiences by simplifying access to movies and events.</p>
      </div>
      <div class="about-card glass">
        <i class="fa-solid fa-users"></i>
        <h3>Our Team</h3>
        <p>We’re a passionate team of developers, designers, and event enthusiasts working to build the future of ticketing.</p>
      </div>
      <div class="about-card glass">
        <i class="fa-solid fa-shield-halved"></i>
        <h3>Why Choose Us?</h3>
        <p>With secure payments, instant booking confirmations, and a smooth user experience, CETS is built for you.</p>
      </div>
    </div>

    <div class="about-extra">
      <h2>✨ Join Us On This Journey</h2>
      <p>Whether you’re a movie lover, a music fan, or a theatre enthusiast — CETS brings all your tickets in one place.</p>
      <a href="register.php" class="btn big">Join Now</a>
    </div>
  </div>
</section>


<footer>
  <p>&copy; 2025 CETS. All rights reserved.</p>
</footer>

</body>
</html>
