<?php
session_start();
include 'php/db.php';

if (!isset($_SESSION['username']) || strtolower($_SESSION['role']) !== 'admin') {
    header("Location: index.php");
    exit();
}

// Fetch all movie bookings
$m = $conn->query("
    SELECT b.id, u.username, m.title, b.cinema, b.date, b.time, b.tickets, b.booking_date
    FROM bookings b
    JOIN movies m ON b.movie_id = m.id
    JOIN users u ON b.user_id = u.id
    ORDER BY b.booking_date DESC
");

// Fetch all event bookings
$e = $conn->query("
    SELECT eb.id, u.username, ev.title, ev.location, ev.date, ev.time, eb.tickets, eb.booked_at
    FROM event_bookings eb
    JOIN events ev ON eb.event_id = ev.id
    JOIN users u ON eb.user_id = u.id
    ORDER BY eb.booked_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CETS - Admin Panel</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/profile.css">
  <link rel="shortcut icon" href="img/logoc.png" />
  <script src="https://kit.fontawesome.com/e37f0e4748.js" crossorigin="anonymous"></script>
</head>
<body>
  <?php include 'nav.php'; ?>

  <div class="profile-container">
    <h2><i class="fa-solid fa-lock"></i> Admin Panel</h2>

    <h3>🎬 All Movie Bookings</h3>
    <?php if ($m->num_rows > 0) { ?>
      <table>
        <tr>
          <th>User</th>
          <th>Movie</th>
          <th>Cinema</th>
          <th>Date</th>
          <th>Time</th>
          <th>Tickets</th>
          <th>Booked At</th>
          <th>Action</th>
        </tr>
        <?php while ($row = $m->fetch_assoc()) { ?>
          <tr>
            <td><?php echo htmlspecialchars($row['username']); ?></td>
            <td><?php echo htmlspecialchars($row['title']); ?></td>
            <td><?php echo htmlspecialchars($row['cinema']); ?></td>
            <td><?php echo date("d M Y", strtotime($row['date'])); ?></td>
            <td><?php echo date("H:i", strtotime($row['time'])); ?></td>
            <td><?php echo $row['tickets']; ?></td>
            <td><?php echo date("d M Y H:i", strtotime($row['booking_date'])); ?></td>
            <td>
              <form class="cancel-form" method="POST" action="php/cancel_booking.php">
                <input type="hidden" name="booking_id" value="<?php echo $row['id']; ?>">
                <input type="hidden" name="type" value="movie">
                <button type="submit" class="cancel-btn">Cancel</button>
              </form>
            </td>
          </tr>
        <?php } ?>
      </table>
    <?php } else { ?>
      <div class="empty-state">
        <i class="fa-solid fa-film"></i> No movie bookings found.
      </div>
    <?php } ?>

    <h3>🎤 All Event Bookings</h3>
    <?php if ($e->num_rows > 0) { ?>
      <table>
        <tr>
          <th>User</th>
          <th>Event</th>
          <th>Location</th>
          <th>Date</th>
          <th>Time</th>
          <th>Tickets</th>
          <th>Booked At</th>
          <th>Action</th>
        </tr>
        <?php while ($row = $e->fetch_assoc()) { ?>
          <tr>
            <td><?php echo htmlspecialchars($row['username']); ?></td>
            <td><?php echo htmlspecialchars($row['title']); ?></td>
            <td><?php echo htmlspecialchars($row['location']); ?></td>
            <td><?php echo date("d M Y", strtotime($row['date'])); ?></td>
            <td><?php echo date("H:i", strtotime($row['time'])); ?></td>
            <td><?php echo $row['tickets']; ?></td>
            <td><?php echo date("d M Y H:i", strtotime($row['booked_at'])); ?></td>
            <td>
              <form class="cancel-form" method="POST" action="php/cancel_booking.php">
                <input type="hidden" name="booking_id" value="<?php echo $row['id']; ?>">
                <input type="hidden" name="type" value="event">
                <button type="submit" class="cancel-btn">Cancel</button>
              </form>
            </td>
          </tr>
        <?php } ?>
      </table>
    <?php } else { ?>
      <div class="empty-state">
        <i class="fa-solid fa-microphone"></i> No event bookings found.
      </div>
    <?php } ?>
  </div>
</body>
</html>
