<?php
session_start();
include 'php/db.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'] ?? null;
$type = $_GET['type'] ?? 'movie'; // default: movie

if (!$id) {
    die("Invalid booking request.");
}

// Fetch movie or event details
if ($type === 'movie') {
    $stmt = $conn->prepare("SELECT * FROM movies WHERE id = ?");
} else {
    $stmt = $conn->prepare("SELECT * FROM events WHERE id = ?");
}
$stmt->bind_param("i", $id);
$stmt->execute();
$item = $stmt->get_result()->fetch_assoc();

if (!$item) {
    die(ucfirst($type) . " not found.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tickets = intval($_POST['tickets']);
    $user = $_SESSION['username'];

    // Get user id
    $u = $conn->prepare("SELECT id FROM users WHERE username=?");
    $u->bind_param("s", $user);
    $u->execute();
    $uid = $u->get_result()->fetch_assoc()['id'];

    if ($type === 'movie') {
        $cinema = $_POST['cinema'];
        $date = $_POST['date'];
        $time = $_POST['time'];

        $b = $conn->prepare("
            INSERT INTO bookings (user_id, movie_id, tickets, cinema, date, time, booking_date)
            VALUES (?,?,?,?,?,?,NOW())
        ");
        $b->bind_param("iiisss", $uid, $id, $tickets, $cinema, $date, $time);

    } else {
        // Event booking goes into event_bookings table
        $b = $conn->prepare("
            INSERT INTO event_bookings (user_id, event_id, tickets, booked_at)
            VALUES (?,?,?,NOW())
        ");
        $b->bind_param("iii", $uid, $id, $tickets);
    }

    $b->execute();
    header("Location: profile.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="shortcut icon" href="img/logoc.png">
  <title>CETS - Book Tickets</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/account.css">
  <script src="https://kit.fontawesome.com/e37f0e4748.js" crossorigin="anonymous"></script>
</head>
<body>
  <form method="POST">
    <h2>Book Tickets for <?php echo htmlspecialchars($item['title']); ?></h2>

    <?php if ($type === 'movie'): ?>
      <!-- Movie booking -->
      <label>Choose Cinema:</label>
      <select name="cinema" required>
        <option value="" disabled selected>Select a cinema</option>
        <option value="Northampton">Northampton</option>
        <option value="Rushden">Rushden</option>
        <option value="London">London</option>
        <option value="Milton Keynes">Milton Keynes</option>
        <option value="Birmingham">Birmingham</option>
      </select>

      <label>Choose Date:</label>
      <input type="date" name="date" min="<?php echo date('Y-m-d'); ?>" required>

      <label>Choose Time:</label>
      <select name="time" required>
        <option value="" disabled selected>Select a time</option>
        <option value="10:00">10:00</option>
        <option value="13:00">13:00</option>
        <option value="16:00">16:00</option>
        <option value="19:00">19:00</option>
        <option value="22:00">22:00</option>
      </select>
    <?php else: ?>
      <!-- Event booking -->
      <div class="event-info">
        <p><strong>Date:</strong> <?php echo date("jS M Y", strtotime($item['date'])); ?></p>
        <p><strong>Time:</strong> <?php echo date("g:i A", strtotime($item['time'])); ?></p>
        <p><strong>Location:</strong> <?php echo htmlspecialchars($item['location']); ?></p>
      </div>
    <?php endif; ?>

    <!-- Tickets -->
    <label>Number of Tickets:</label>
    <div class="ticket-controls">
      <span class="ticket-btn" onclick="updateTickets(-1)">−</span>
      <input type="number" name="tickets" id="tickets" value="1" min="1" max="10" readonly>
      <span class="ticket-btn" onclick="updateTickets(1)">+</span>
    </div>

    <button type="submit">Confirm Booking</button>
    <a href="<?php echo $type === 'movie' ? 'movies.php' : 'events.php'; ?>" class="btn-link return">Return Back</a>
  </form>

  <script>
    function updateTickets(change) {
      let tickets = document.getElementById('tickets');
      let value = parseInt(tickets.value) + change;
      if (value >= 1 && value <= 10) {
        tickets.value = value;
      }
    }
  </script>
</body>
</html>
