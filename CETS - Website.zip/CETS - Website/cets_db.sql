-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2025 at 06:17 PM
-- Server version: 8.0.43
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cets_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `movie_id` int NOT NULL,
  `tickets` int NOT NULL,
  `booking_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `cinema` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `type` enum('movie','event') NOT NULL DEFAULT 'movie'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `movie_id`, `tickets`, `booking_date`, `cinema`, `date`, `time`, `type`) VALUES
(6, 1, 3, 2, '2025-09-25 02:15:26', 'Northampton', '2025-09-28', '19:00:00', 'movie'),
(7, 1, 3, 1, '2025-09-25 02:19:40', 'Milton Keynes', '2025-09-28', '13:00:00', 'movie'),
(8, 2, 2, 3, '2025-09-25 02:20:06', 'London', '2025-10-04', '10:00:00', 'movie'),
(10, 1, 3, 2, '2025-09-25 02:46:55', 'London', '2025-09-30', '13:00:00', 'movie');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int NOT NULL,
  `title` varchar(100) NOT NULL,
  `poster` varchar(100) NOT NULL,
  `location` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `poster`, `location`, `date`, `time`) VALUES
(12, 'Christmas Event: 2025', 'event1.jpg', 'Northampton', '2025-12-25', '18:00:00'),
(13, 'Hamilton The Big Event', 'event2.jpg', 'Northampton', '2025-10-01', '20:30:00'),
(14, 'National Theatre Live', 'event3.jpg', 'London', '2025-11-05', '19:00:00'),
(15, 'Radiohead X Nosferatu', 'radiohead.jpg', 'Reading', '2025-10-25', '14:00:00'),
(16, 'Dude Perfect: The Hero Tour', 'hero.jpg', 'Luton', '2025-10-30', '20:00:00'),
(17, 'Andrea Bocelli: Because I Believe', 'andrea.jpg', 'Leicester', '2025-11-10', '14:30:00'),
(18, 'Taylor Swift | Release Party', 'taylor.jpg', 'Banbury', '2025-11-22', '17:35:00'),
(19, 'John Cleese Packs It In', 'john.jpg', 'Northampton', '2025-11-02', '20:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `event_bookings`
--

CREATE TABLE `event_bookings` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `event_id` int NOT NULL,
  `tickets` int NOT NULL,
  `booked_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `event_bookings`
--

INSERT INTO `event_bookings` (`id`, `user_id`, `event_id`, `tickets`, `booked_at`) VALUES
(2, 1, 19, 1, '2025-09-25 02:19:27'),
(4, 2, 12, 1, '2025-09-25 02:20:23'),
(5, 2, 18, 1, '2025-09-25 02:20:27'),
(7, 1, 12, 3, '2025-09-25 02:47:02');

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `id` int NOT NULL,
  `title` varchar(100) NOT NULL,
  `poster` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`id`, `title`, `poster`) VALUES
(1, 'The Batman', 'movie1.jpg'),
(2, 'Superman', 'movie2.jpg'),
(3, 'F1 The Movie', 'movie3.jpg'),
(4, 'The Long Walk', 'movie4.jpg'),
(5, 'Tron: Ares', 'movie5.jpg'),
(6, 'Frozen', 'frozen.jpg'),
(7, 'Aliens', 'aliens.jpg'),
(8, 'Final Destination', 'final.jpg'),
(9, 'The Lost Bus', 'lost.jpg'),
(10, 'The Strangers 2', 'strangers.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`) VALUES
(1, 'Maxim', 'pereu.maxy@gmail.com', '$2y$10$ikY1qGR.7MUSxBQs0iRRhOgowECVdMDzYPECiEKf0.2u6GFySFGfu', 'user'),
(2, 'Test', 'test@gmail.com', '$2y$10$nQdsGZ4Z2mg14uvxuWeq2ug9Qr2CC3k5OV49JN7FUPr9TW9XwYPMa', 'user'),
(3, 'Admin', 'admin@gmail.com', '$2y$10$qoRmmFKSqKaua7HFIvdppeG8CeGT3HjgmLlNEL0RB.RzAXIRE6AXK', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `movie_id` (`movie_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_bookings`
--
ALTER TABLE `event_bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `event_bookings`
--
ALTER TABLE `event_bookings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`id`);

--
-- Constraints for table `event_bookings`
--
ALTER TABLE `event_bookings`
  ADD CONSTRAINT `event_bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `event_bookings_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
